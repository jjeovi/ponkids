package com.meta.ponkids.domain.{domain}.dto;

import com.meta.ponkids.domain.{domain}.entity.{Domain};

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// TODO Dto 항목 setting
@Data
@NoArgsConstructor
public class {Domain}ModDto {
	
	
	private Long {domain}Sn;
	
    private String updusrId;      	// 수정자 ID
    
    private String updusrIp;      	// 수정자 IP
	
	// TODO 생성자();
	//builder 생성
	@Builder
	public {Domain}ModDto (Long {domain}Sn, String updusrId, String updusrIp) {
		this.{domain}Sn = {domain}Sn;
		this.updusrId = updusrId;
		this.updusrIp = updusrIp;
	}
	
	
	// TODO toEntity();
	// Dto to Entity 메소드 생성
	public {Domain} toEntity() {
		return {Domain}.builder()
				.{domain}Sn({domain}Sn)
				.updusrId(updusrId)
				.updusrIp(updusrIp)
				.build();
	}
	
	
	//TODO toDto();
	// Entity to Dto 메소드는 DTO 내부에서 생성.
	public {Domain}ModDto toDto({Domain} {domain}) {
		return {Domain}ModDto.builder()
				.{domain}Sn({domain}.get{Domain}Sn())
				.updusrId({domain}.getUpdusrId())
				.updusrIp({domain}.getUpdusrIp())
				.build();
	}

}
