package com.meta.ponkids.domain.{domain}.dto;

import com.meta.ponkids.domain.{domain}.entity.{Domain};

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

//TODO Dto 항목 setting
@Data
@NoArgsConstructor
public class {Domain}SaveDto {
	
	private Long {domain}Sn;
	
	private String registerId;      // 등록자 id
	
	private String registerIp;      // 등록자 ip
	
	private String updusrId;      	// 수정자 id
	
	private String updusrIp;      	// 수정자 ip
	
	// TODO 생성자();
	@Builder
	public {Domain}SaveDto(Long {domain}Sn) {
		this.{domain}Sn = {domain}Sn;
		this.registerId = registerId;
		this.registerIp = registerIp;
		this.updusrId = updusrId;
		this.updusrIp = updusrIp;
	}
	
	// TODO toEntity();
	// Dto to Entity 메소드 생성
	public {Domain} toEntity() {
		return {Domain}.builder()
				.{domain}Sn({domain}Sn)
				.registerId(registerId)
				.registerIp(registerIp)
				.updusrId(updusrId)
				.updusrIp(updusrIp)
				.build();
	}

}
