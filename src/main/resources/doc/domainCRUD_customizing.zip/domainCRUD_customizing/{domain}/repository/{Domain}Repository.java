package com.meta.ponkids.domain.{domainPath}.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.meta.ponkids.domain.{domainPath}.entity.{Domain};
import com.meta.ponkids.domain.{domainPath}.repository.custom.{Domain}RepositoryCustom;

// TODO PK(*ID) 체크
public interface {Domain}Repository extends JpaRepository<{Domain}, Long>, {Domain}RepositoryCustom {
	
	Optional<{Domain}> findById( Long pk );	// TODO PK(*ID) 체크
}
