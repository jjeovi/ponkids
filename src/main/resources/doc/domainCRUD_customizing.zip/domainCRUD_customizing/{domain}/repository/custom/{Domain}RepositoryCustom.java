package com.meta.ponkids.domain.{domainPath}.repository.custom;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.meta.ponkids.domain.{domainPath}.dto.{Domain}ListDto;

public interface {Domain}RepositoryCustom {
	
	Page<{Domain}ListDto> getList( {Domain}ListDto listDto, Pageable pageable );

}
